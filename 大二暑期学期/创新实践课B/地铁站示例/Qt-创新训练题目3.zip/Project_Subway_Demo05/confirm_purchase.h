/********************************************************************************
  * 文件名：confirm_purchase.h
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：确认支付界面头文件，声明了相关按钮、输入栏对象，并设置了相应信号函数
  *
  ******************************************************************************
  * 注意：
  *
  ******************************************************************************  */
#ifndef CONFIRM_PURCHASE_H
#define CONFIRM_PURCHASE_H

#include <QDialog>
#include <QPushButton>
#include <QLineEdit>
#include <QMessageBox>

namespace Ui {
class confirm_purchase;
}

class confirm_purchase : public QDialog
{
    Q_OBJECT

public:
    explicit confirm_purchase(QWidget *parent = nullptr);
    ~confirm_purchase();

private:
    Ui::confirm_purchase *ui;

    QLineEdit *money_pay;
    QPushButton *btn_yes;
    QPushButton *btn_no;

signals:
    void confirm_purchase_back();
    void back_to_mainscence_confirm_purchase();
};

#endif // CONFIRM_PURCHASE_H

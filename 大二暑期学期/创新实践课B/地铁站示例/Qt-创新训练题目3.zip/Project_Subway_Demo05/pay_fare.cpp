/********************************************************************************
  * 文件名：pay_fare.cpp
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：购票界面组购票数量窗口实现，将之前购票界面组的起点站、终点站输入窗口获得的站点作为输入给
  *      information_subway.cpp文件下的get_information_of_subway函数，获得票价
  ******************************************************************************
  * 注意：该文件使用了double类型的全局变量station_price，用以获得用户选择的线路的票价
  *
  ******************************************************************************  */
#include "pay_fare.h"
#include "ui_pay_fare.h"

#include "buy_ticket_origin.h"

double station_price=0;

pay_fare::pay_fare(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::pay_fare)
{
    ui->setupUi(this);
    setWindowTitle("地铁售票系统v0.1");
    setFixedSize(WIDTH,HEIGHT);
    this->setWindowIcon(QPixmap(":/subway/mysource/logo.png"));

    window_confirm_purchase=new confirm_purchase;
    connect(window_confirm_purchase,&confirm_purchase::back_to_mainscence_confirm_purchase,this,[=](){
        emit back_to_mainscence_pay_fare();
        window_confirm_purchase->close();
        this->hide();
        number_tickets->clear();
    });//检测到支付界面发出的回到主界面菜单后，发送信号给父窗口，逐级回到主界面；

    connect(window_confirm_purchase,&confirm_purchase::confirm_purchase_back,this,[=](){
       window_confirm_purchase->close();
    });//检测支付界面发送的信号，发出信号后，将支付界面隐藏

    btn_esc=new QPushButton("退回",this);
    btn_esc->setGeometry(960,600,100,62);
    connect(btn_esc,&QPushButton::clicked,this,[=](){
        emit pay_fare_back();
    });

    btn_confirm_number=new QPushButton("购买",this);
    btn_confirm_number->setGeometry(820,400,240,100);
    connect(btn_confirm_number,&QPushButton::clicked,this,[=](){
        QString number=number_tickets->text();
        QByteArray ba=number.toLatin1();
        char * s=ba.data();
        bool valid_number_tickets=QChar::isNumber(*s);
        if(valid_number_tickets)
        {
            window_confirm_purchase->show();
        }
        else
        {
            QMessageBox::critical(this,"错误","请输入数字");
        }
    });//检测用户是否输入了数字，若输入了数字，则进入支付界面，否则提示错误

    show_price=new QLabel("此处将会显示您要支付的价格",this);//显示用户需要支付的价格
    show_price->setGeometry(820,130,240,100);

    number_tickets=new QLineEdit(this);
    number_tickets->setPlaceholderText("请在此输入您要购买的票数");
    number_tickets->setGeometry(820,200,240,110);

    show_price_timer= new QTimer(this);//设定一个计时器，读取用户输入的购票数量，显示用户应当支付的价格
    connect(show_price_timer,&QTimer::timeout,this,[=](){
        QString number=number_tickets->text();//票价在此进行计算，进行阶梯票价的设计
        QByteArray ba=number.toLatin1();
        char * s=ba.data();
        bool valid_number_tickets=QChar::isNumber(*s);
        if(valid_number_tickets)
        {
            int i=number.toUInt();
            station_price=get_information_of_subway(my_origin,my_destination);
            if(station_price<=3)
                station_price=2*i;
            else
            {
                if(station_price>3&&station_price<=15)
                    station_price=(station_price*0.5+0.5)*i;
                else
                {
                    if(station_price>15)
                        station_price=10*i;
                }
            }
            QString ticket_fare=QString::number(station_price);
            show_price->setText("您要支付的票价为"+ticket_fare+"元");
        }
    });
    show_price_timer->start(1000);

    typeface.setPointSize(20);
    typeface.setFamily("华文新魏");
    number_tickets->setFont(typeface);
    number_tickets->setAlignment(Qt::AlignHCenter);
    typeface.setPixelSize(15);
    typeface.setFamily("楷体");
    typeface.setBold(true);
    btn_esc->setFont(typeface);
    typeface.setPixelSize(25);
    typeface.setFamily("楷体");
    btn_confirm_number->setFont(typeface);
}

pay_fare::~pay_fare()
{
    delete ui;
}

void pay_fare::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap Buy_ticket_scence;
    Buy_ticket_scence.load(":/subway/mysource/background_01.png");
    painter.drawPixmap(0,0,this->width(),this->height(),Buy_ticket_scence);
    Buy_ticket_scence.load(":/subway/mysource/line_network.png");
    painter.drawPixmap(50,200,650,400,Buy_ticket_scence);
}//重新绘图事件，绘出购票界面背景

void pay_fare::keyReleaseEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape)
    {
        emit pay_fare_back();
    }
}

/********************************************************************************
  * 文件名：map_query.cpp
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：地图查询界面窗口实现文件，重写了绘图事件和相关键盘事件，并对鼠标点击、移动、释放事件
  *      进行了重写，实现线路图的拖拽查看功能。接收输入栏中输入的站点名，并进行相应判断，显示相应站点信息
  ******************************************************************************
  * 注意：本文件中使用double类型的全局变量window_length，用以表示线路图缩放比例
  *
  ******************************************************************************  */
#include "map_query.h"
#include "information_subway.h"

double window_length=1000.0;

QPoint readyapply;
QPoint prereadyapply;
QPoint afterapply=QPoint(0,0);

map_query::map_query(QWidget *parent) : QMainWindow(parent)
{
    setWindowTitle("地铁售票系统v0.1");
    setFixedSize(WIDTH,HEIGHT);
    this->setWindowIcon(QPixmap(":/subway/mysource/logo.png"));

    btn_esc = new QPushButton("返回主界面",this);
    btn_esc ->setGeometry(960,600,100,62);
    connect(btn_esc,&QPushButton::clicked,this,[=](){
        emit map_query_back();
        query_station->clear();
        readyapply=QPoint(0,0);
        prereadyapply=QPoint(0,0);
        afterapply=QPoint(0,0);
        window_length=1000;
        repaint();
    });//退出按钮，点击后发出退出信号

    btn_zoomin=new QPushButton("+",this);
    btn_zoomin->setGeometry(560,180,30,30);
    connect(btn_zoomin,&QPushButton::clicked,this,[&](){
        if(window_length-100>=100)
        {
            window_length-=100;
            repaint();
        }
    });

    btn_zoomout=new QPushButton("-",this);
    btn_zoomout->setGeometry(560,220,30,30);
    connect(btn_zoomout,&QPushButton::clicked,this,[&](){
        if(window_length+100<=1000)
        {
            window_length+=100;
            repaint();
        }
    });
    btn_default=new QPushButton("恢复",this);
    btn_default->setGeometry(560,260,50,30);
    connect(btn_default,&QPushButton::clicked,this,[&](){
        readyapply=QPoint(0,0);
        prereadyapply=QPoint(0,0);
        afterapply=QPoint(0,0);
        window_length=1000;
        repaint();
    });

    query_station = new QLineEdit(this);
    query_station->setPlaceholderText("在此输入您要查询的站点");
    query_station->setGeometry(800,280,220,100);

    station_list << "怒江公园" << "北陵公园" << "丁香湖"  << "淮河街沈医二院"<<"中医药大学"<<"重工街"
                 <<"铁西广场"<<"青年大街"<<"滂江街"<<"黎明广场"<<"奥体中心"<<"长青南街"<<"全运路"<<"张沙布";
    station_name = new QCompleter(station_list);
    query_station->setCompleter(station_name);//设定模糊查询

    QLabel * information_of_station_label=new QLabel("此处将会显示您要查询的站点的信息",this);
    information_of_station_label->setGeometry(800,140,220,200);
    information_of_station_label->setAlignment(Qt::AlignHCenter);

    btn_search = new QPushButton("查询站点",this);
    btn_search->setGeometry(800,400,220,80);
    connect(btn_search,&QPushButton::clicked,this,[=]()mutable{
        QString station_search;
        station_search=query_station->text();
        int i =get_station_information(station_search);
        show_information(i,*information_of_station_label);
    });//查找按钮，点击后读取用户输入的文本，从站点中找出匹配的站点，并给出信息

    btn_enter_buy_ticket = new QPushButton("开始购票",this);
    btn_enter_buy_ticket->setGeometry(800,500,220,80);
    connect(btn_enter_buy_ticket,&QPushButton::clicked,this,[=](){
        emit map_query_switch();
        query_station->clear();
    });//开始购票按钮，点击后进入购票界面

    show_information_timer=new QTimer(this);//设定一个计时器，获取用户输入的信息，显示相应站点的信息
    connect(show_information_timer,&QTimer::timeout,this,[=](){
        QString station_search;
        station_search=query_station->text();
        int i =get_station_information(station_search);
        show_information(i,*information_of_station_label);
    });//开启定时器后，读取用户输入的站点，在列表中匹配相应站点并显示信息
    show_information_timer->start(1000);
    /*地图查看功能*/

    typeface.setPointSize(20);
    typeface.setFamily("华文新魏");
    query_station->setFont(typeface);
    query_station->setAlignment(Qt::AlignHCenter);
    typeface.setPixelSize(15);
    typeface.setFamily("楷体");
    typeface.setBold(true);
    btn_esc->setFont(typeface);
    typeface.setPixelSize(25);
    typeface.setFamily("楷体");
    typeface.setBold(true);
    btn_search->setFont(typeface);
    btn_enter_buy_ticket->setFont(typeface);
}

void map_query::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap query_scence;
    query_scence.load(":/subway/mysource/background_01.png");
    painter.drawPixmap(0,0,this->width(),this->height(),query_scence);

    QRectF target(150,180,400,400);
    QPoint border_point1;
    border_point1.setX(afterapply.x()+readyapply.x()*(window_length/400.0));
    border_point1.setY(afterapply.y()+readyapply.y()*(window_length/400.0));
    QPoint border_point2=QPoint(border_point1+QPoint(window_length,window_length));
    QRectF source(border_point1,border_point2);
    QImage shenyang_route;
    shenyang_route.load(":/subway/mysource/line_network.png");
    painter.drawImage(target,shenyang_route,source);
}

void map_query::keyReleaseEvent(QKeyEvent *event)
{
    if(event->key()==Qt::Key_Escape)
    {
     emit map_query_back();
     readyapply=QPoint(0,0);
     prereadyapply=QPoint(0,0);
     afterapply=QPoint(0,0);
     window_length=1000;
     repaint();
    }
}

int map_query::get_station_information(QString i_station_name)//读取界面中输入栏的文本，
{                                                               //与站点数组中的所有站点一一比较，找到站点后，返回该站点的编号

    int station_search_node=-1;
    for(int i=0;i<=13;i++)
    {
        if(i_station_name==stations_search[i].name)
        {
            station_search_node=stations_search[i].node;
            break;
        }
    }
    return station_search_node;
}

void map_query::show_information(int station_node, QLabel &i_information_station_label)
{
    if(station_node!=-1)
    {
        switch(station_node)
        {
        case 1:
            i_information_station_label.setText("怒江公园\n9号线 怒江公园方向 始:末:\n建筑大学方向 始:末:");
            break;
        case 2:
            i_information_station_label.setText("北陵公园\n2号线 莆田路方向 始06:04末23:34\n全运路方向 始06:14末23:24");
            break;
        case 3:
            i_information_station_label.setText("丁香湖\n10号线 丁香湖方向 始:末:\n张沙布方向 始末");
            break;
        case 4:
            i_information_station_label.setText("淮河街沈医二院\n9号线 怒江公园方向 始末\n          建筑大学方向 始末\n10号线 丁香湖方向 始末\n          张沙布方向 始末");
            break;
        case 5:
            i_information_station_label.setText("中医药大学\n2号线 莆田路方向 始06:02末23:32\n          全运路方向 始06:16末23:26\n10号线 丁香湖方向 始末\n          张沙布方向 始末");
            break;
        case 6:
            i_information_station_label.setText("重工街\n1号线 十三号街方向 始06:35末22:38\n          黎明广场方向 始05:51末22:21");
            break;
        case 7:
            i_information_station_label.setText("铁西广场\n1号线 十三号街方向 始06:28末22:30\n          黎明广场方向 始05:59末22:29\n9号线 怒江公园方向 始末\n          建筑大学方向 始末");
            break;
        case 8:
            i_information_station_label.setText("青年大街\n1号线 十三号街方向 始06:14末22:17\n          黎明广场方向 始6:13末22:43\n2号线 莆田路方向 始5:50末23:20\n          全运路方向 始6:27末23:37");
            break;
        case 9:
            i_information_station_label.setText("滂江街\n1号线 十三号街方向 始06:03末22:03\n          黎明广场方向 始6:24末22:54\n10号线 丁香湖方向 始末\n          张沙布方向 始末");
            break;
        case 10:
            i_information_station_label.setText("黎明广场\n1号线 十三号街方向 始06:00末22:00\n          黎明广场方向 始末");
            break;
        case 11:
            i_information_station_label.setText("奥体中心\n2号线 莆田路方向 始5:38末23:08\n          全运路方向 始6;40末23:50\n9号线 怒江公园方向 始末\n          建筑大学方向 始末");
            break;
        case 12:
            i_information_station_label.setText("长青南街\n9号线 怒江公园方向 始末\n          建筑大学方向 始末\n10号线 丁香湖方向 始末\n          张沙布方向 始末");
            break;
        case 13:
            i_information_station_label.setText("全运路\n2号线 浦田路方向 始05:30末23:00");
            break;
        case 14:
            i_information_station_label.setText("张沙布\n10号线 丁香湖方向 始末\n          张沙布方向 始末");
            break;
        default:break;
        }
    }
}

void map_query::mousePressEvent(QMouseEvent *e)
{
    if(e->position().x()<550&&e->position().x()>150&&e->position().y()>180&&e->position().y()<580)
    {
        prereadyapply.setX(e->position().x());
        prereadyapply.setY(e->position().y());
    }
}

void map_query::mouseMoveEvent(QMouseEvent *e)
{

    if(e->position().x()<550&&e->position().x()>150&&e->position().y()>180&&e->position().y()<580)
    {
        readyapply.setX(prereadyapply.x()-e->position().x());
        readyapply.setY(prereadyapply.y()-e->position().y());
        repaint();//与绘图事件联动，实现鼠标拖拽改变图片的显示情况
    }
}

void map_query::mouseReleaseEvent(QMouseEvent *)
{
    readyapply.setX(readyapply.x()*window_length/400.0);
    readyapply.setY(readyapply.y()*window_length/400.0);
    afterapply=afterapply+readyapply;
    readyapply=QPoint(0,0);
}

/********************************************************************************
  * 文件名：buy_ticket.h
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：程序购票界面组的起点站输入窗口头文件，声明了该界面的相关按钮以及输入栏的对象，
  *      并设置了一些信号函数
  ******************************************************************************
  * 注意：本文件中声明了两个QString类型的全局变量my_origin和my_destination，
  *      使后续在终点站输入窗口可以确定票价
  ******************************************************************************  */
#ifndef BUY_TICKET_ORIGIN_H
#define BUY_TICKET_ORIGIN_H

#include <QWidget>
#include <QString>
#include <QLabel>
#include <QPainter>
#include <QPushButton>
#include <QDebug>
#include <QKeyEvent>
#include <QCompleter>
#include <QLineEdit>
#include <QLabel>
#include <QMessageBox>
#include <QFont>

#include "buy_ticket_destination.h"
#include "information_subway.h"

namespace Ui {
class Buy_Ticket;
}

extern QString my_origin;
extern QString my_destination;

class Buy_Ticket_Origin : public QWidget
{
    Q_OBJECT

public:
    explicit Buy_Ticket_Origin(QWidget *parent = nullptr);
    ~Buy_Ticket_Origin();
    void paintEvent(QPaintEvent *);
    void keyReleaseEvent(QKeyEvent * event);

private:
    Ui::Buy_Ticket *ui;

    const int WIDTH=1080;
    const int HEIGHT=668;
    buy_ticket_destination * window_buy_ticket_destination=NULL;
    QLineEdit * route_enquiry_origin;
    QStringList station_list;//设定模糊查询的查询列表
    QCompleter *station_name;
    QPushButton *btn_esc;
    QPushButton *btn_confirm_origin;
    QFont typeface;

signals:
    void buy_ticket_back();
};

#endif // BUY_TICKET_ORIGIN_H

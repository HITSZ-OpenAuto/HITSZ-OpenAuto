/********************************************************************************
  * 文件名：widget.h
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：程序主窗口头文件，包含了主窗口使用的控件的相关库，声明了显示文本以及按钮对象
  *
  ******************************************************************************
  * 注意：
  *
  ******************************************************************************  */
#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QPainter>
#include <QPushButton>
#include <QLabel>
#include <QFont>
#include <QPalette>

#include "buy_ticket_origin.h"
#include "map_query.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    ~Widget();

private:
    Ui::Widget *ui;

    const int WIDTH=1080;
    const int HEIGHT=668;
    Buy_Ticket_Origin * window_buy_ticket=NULL;
    map_query * window_map_query=NULL;
    QPushButton * mainscence_btn1;
    QPushButton * mainscence_btn2;
    QPushButton * mainscence_btn3;
    QLabel *information_author;
    QPalette palette;
    QFont typeface;
};
#endif // WIDGET_H

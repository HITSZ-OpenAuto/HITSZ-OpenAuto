/********************************************************************************
  * 文件名：main.cpp
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：主函数文件，调用widget类的w对象和information_me类的welcome对象，显示购票系统窗口
  *      和指引界面，后续操作通过窗口自身设置的按钮等进行
  ******************************************************************************
  * 注意：
  *
  ******************************************************************************  */
#include "widget.h"
#include "information_me.h"

#include <QApplication>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.show();
    information_me welcome;
    welcome.show();
    return a.exec();
}

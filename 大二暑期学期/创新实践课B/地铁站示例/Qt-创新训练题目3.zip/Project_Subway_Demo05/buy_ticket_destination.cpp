/********************************************************************************
  * 文件名：buy_ticket_destination
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：购票界面组终点站站输入窗口实现文件，重写了绘图事件和相关键盘事件，实现界面背景绘制和Esc键返回
  *      对相关按钮进行了连接，实现显示界面的切换等
  ******************************************************************************
  * 注意：该文件使用了information_subway文件中的两个全局变量，进行输入站点的比较判断和路径的输出
  *
  ******************************************************************************  */
#include "buy_ticket_destination.h"
#include "ui_buy_ticket_destination.h"

#include "buy_ticket_origin.h"

buy_ticket_destination::buy_ticket_destination(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::buy_ticket_destination)
{
    ui->setupUi(this);
    setWindowTitle("地铁售票系统v0.1");
    setFixedSize(WIDTH,HEIGHT);
    this->setWindowIcon(QPixmap(":/subway/mysource/logo.png"));

    connect(window_pay_fare,&pay_fare::pay_fare_back,this,[=](){
        this->show();
        this->setGeometry(window_pay_fare->geometry());
        window_pay_fare->hide();
    });//检测到购票界面发出的退出指令后，退回到当前选择终点站的界面

    connect(window_pay_fare,&pay_fare::back_to_mainscence_pay_fare,this,[=](){
       emit back_to_mainscence_buy_ticket_destination();
       route_enquiry_destination->clear();
       //show_route_timer->stop();
    });//检测到购票窗口发出的返回主窗口信号后，发送返回到主窗口的信号，逐级返回到主窗口

    btn_line_1=new QPushButton("一号线",this);
    btn_line_1->setGeometry(80,620,120,40);
    connect(btn_line_1,&QPushButton::clicked,this,[&](){
        line=1;
        repaint();
    });//按下按钮后，显示相应的线路信息

    btn_line_2=new QPushButton("二号线",this);
    btn_line_2->setGeometry(230,620,120,40);
    connect(btn_line_2,&QPushButton::clicked,this,[&](){
        line=2;
        repaint();
    });

    btn_line_3=new QPushButton("九号线",this);
    btn_line_3->setGeometry(380,620,120,40);
    connect(btn_line_3,&QPushButton::clicked,this,[&](){
        line=3;
        repaint();
    });

    btn_line_4=new QPushButton("十号线",this);
    btn_line_4->setGeometry(530,620,120,40);//按下按钮后重绘地图
    connect(btn_line_4,&QPushButton::clicked,this,[&](){
        line=4;
        repaint();
    });

    btn_default_picture=new QPushButton("恢复",this);
    btn_default_picture->setGeometry(700,620,80,40);
    connect(btn_default_picture,&QPushButton::clicked,this,[&](){
        line=0;
        repaint();
    });

    show_route=new QLabel("此处将会显示您的路线",this);
    show_route->setGeometry(820,100,400,100);

    route_enquiry_destination = new QLineEdit(this);//输入查询，获得用户输入的终点站
    route_enquiry_destination->setPlaceholderText("在此处输入终点站");
    route_enquiry_destination->setGeometry(820,200,240,110);

    station_list << "怒江公园" << "北陵公园" << "丁香湖"  << "淮河街沈医二院"<<"中医药大学"<<"重工街"
                 <<"铁西广场"<<"青年大街"<<"滂江街"<<"黎明广场"<<"奥体中心"<<"长青南街"<<"全运路"<<"张沙布";
    station_name = new QCompleter(station_list);//设置Eidt的模糊查询对象
    route_enquiry_destination->setCompleter(station_name);

    btn_esc = new QPushButton("返回",this);
    btn_esc->setGeometry(960,600,100,62);
    connect(btn_esc,&QPushButton::clicked,this,[=](){
        emit buy_ticket_destination_back();
    });//按下关闭按钮后，发送返回信号，回到起点站选择的界面

    btn_confirm_destination=new QPushButton("购票",this);
    btn_confirm_destination->setGeometry(820,400,240,100);
    connect(btn_confirm_destination,&QPushButton::clicked,this,[=]()mutable{
        my_destination=route_enquiry_destination->text();
        bool wt_valid_destination=false;
        for(int i=0;i<=13;i++)//判断输入的站点是否在站点的列表中，若在，则给出购票窗口，若不在则进行提示
        {
            if(my_destination==stations_search[i].name)
            {
                wt_valid_destination=true;
                break;
            }
        }
        if(wt_valid_destination)
        {
            if(my_origin==my_destination)
            {
                QMessageBox::critical(this,"错误","请输入不同的站点作为起点站和终点站");
            }
            else
            {
                get_information_of_subway(my_origin,my_destination);
                window_pay_fare->show();
                this->hide();
                window_pay_fare->setGeometry(this->geometry());
            }
        }
        else
        {
            QMessageBox::critical(this,"错误","您输入的站点不在列表中");
        }
    });//按下购票按钮后，弹出支付窗口，开始购票，显示需要支付的价格

    show_route_timer=new QTimer(this);
    connect(show_route_timer,&QTimer::timeout,this,[=](){
        my_destination=route_enquiry_destination->text();
        bool wt_valid_destination=false;
        for(int i=0;i<=13;i++)//判断输入的站点是否在站点的列表中，若在，则给出购票窗口，若不在则进行提示
        {
            if(my_destination==stations_search[i].name)
            {
                wt_valid_destination=true;
                break;
            }
        }
        if(wt_valid_destination)
        {
            if(my_origin==my_destination)
            {
            }
            else
            {
                get_information_of_subway(my_origin,my_destination);
                QString test="";
                for(int i=0;i<=13;i++)
                {
                    if(station_list_route[i]!="0"&&station_list_route[i]!=my_destination)
                        test+=station_list_route[i]+"->";
                    if(i%3==0&&i!=0)
                        test+="\n";
                    if(station_list_route[i]==my_destination)
                        test+=station_list_route[i];
                }
                show_route->setText(test);
                test="";
                for(int i=0;i<=13;i++)
                    station_list_route[i]="0";
            }
        }
    });
    show_route_timer->start(1000);

    typeface.setPointSize(20);
    typeface.setFamily("华文新魏");
    route_enquiry_destination->setFont(typeface);
    route_enquiry_destination->setAlignment(Qt::AlignHCenter);
    typeface.setPixelSize(15);
    typeface.setFamily("楷体");
    typeface.setBold(true);
    btn_esc->setFont(typeface);
    typeface.setPixelSize(25);
    typeface.setFamily("楷体");
    btn_confirm_destination->setFont(typeface);
}

buy_ticket_destination::~buy_ticket_destination()
{
    delete ui;
}

void buy_ticket_destination::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap Buy_ticket_scence;
    Buy_ticket_scence.load(":/subway/mysource/background_01.png");
    painter.drawPixmap(0,0,this->width(),this->height(),Buy_ticket_scence);
    switch (line)
    {
        case 0:
        Buy_ticket_scence.load(":/subway/mysource/line_network.png");
        break;
        case 1:
        Buy_ticket_scence.load(":/subway/mysource/shenyang_line1.png");
        break;
        case 2:
        Buy_ticket_scence.load(":/subway/mysource/shenyang_line2.png");
        break;
        case 3:
        Buy_ticket_scence.load(":/subway/mysource/shenyang_line9.png");
        break;
        case 4:
        Buy_ticket_scence.load(":/subway/mysource/shenyang_line10.png");
        break;
    }
    painter.drawPixmap(50,200,650,400,Buy_ticket_scence);
}//重新绘图事件，绘出购票界面背景

void buy_ticket_destination::keyReleaseEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape)
    {
        emit buy_ticket_destination_back();
        line=0;
    }
}

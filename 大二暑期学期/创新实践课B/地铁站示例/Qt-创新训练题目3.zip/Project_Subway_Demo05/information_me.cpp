/********************************************************************************
  * 文件名：information_me.cpp
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：用户指引界面实现文件，对按钮的功能进行了设置，并重写鼠标滚轮事件，实现通过鼠标滚轮
  *      查看指引的功能
  ******************************************************************************
  * 注意：该文件中使用了double类型的变量notice_height，通过改变图片的显示位置来实现
  *      对指引信息的查看
  ******************************************************************************  */
#include "information_me.h"
#include "ui_information_me.h"

information_me::information_me(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::information_me)
{
    ui->setupUi(this);
    setWindowTitle("用户须知");
    setFixedSize(640,480);
    this->setWindowIcon(QPixmap(":/subway/mysource/logo.png"));

    //("用户须知，本产品由XXX开发");
    btn_confirm = new QPushButton("我已知悉",this);
    btn_confirm->setGeometry(270,420,100,40);
    connect(btn_confirm,&QPushButton::clicked,this,&QWidget::close);
}

void information_me::paintEvent(QPaintEvent *)
{
    QPainter painter(this);

    QImage notice;
    QRect target(0,0,640,480);
    QRect source (0,notice_height,1106,780);
    notice.load(":/subway/mysource/notice.png");
    painter.drawImage(target,notice,source);
}


information_me::~information_me()
{
    delete ui;
}

void information_me::wheelEvent(QWheelEvent *event)
{
    if(event->angleDelta().y()>0)//滑轮控制
    {
        if((notice_height-200)>=0)
            notice_height-=200;
    }
    else
    {
        if(notice_height<=10092)
            notice_height+=200;
    }
    repaint();
}

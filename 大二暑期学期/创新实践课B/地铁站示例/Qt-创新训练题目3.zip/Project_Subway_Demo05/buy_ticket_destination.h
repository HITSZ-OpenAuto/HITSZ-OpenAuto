/********************************************************************************
  * 文件名：buy_ticket_destination.h
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：购票界面组的终点站输入窗口头文件，声明了一些按钮、输入栏、相关显示控件的对象，
  *      并设置了一些信号函数
  ******************************************************************************
  * 注意：在该文件中定义了一个int类型变量line，实现点击按钮显示不同线路的线路图的功能
  *
  ******************************************************************************  */
#ifndef BUY_TICKET_DESTINATION_H
#define BUY_TICKET_DESTINATION_H

#include <QWidget>
#include <QPaintEvent>
#include <QPainter>
#include <QPushButton>
#include <QDebug>
#include <QKeyEvent>
#include <QCompleter>
#include <QLineEdit>
#include <QLabel>
#include <QMessageBox>
#include <QTimer>
#include <QFont>

#include "pay_fare.h"
#include "information_subway.h"

namespace Ui {
class buy_ticket_destination;
}

class buy_ticket_destination : public QWidget
{
    Q_OBJECT

public:
    explicit buy_ticket_destination(QWidget *parent = nullptr);
    ~buy_ticket_destination();
    void paintEvent(QPaintEvent *);
    void keyReleaseEvent(QKeyEvent * event);

    pay_fare *window_pay_fare = new pay_fare;

private:
    Ui::buy_ticket_destination *ui;

    const int WIDTH=1080;
    const int HEIGHT=668;
    int line=0;
    QTimer *show_route_timer;
    QLabel *show_route;
    QStringList station_list;
    QLineEdit * route_enquiry_destination;
    QCompleter *station_name;
    QPushButton *btn_esc;
    QPushButton *btn_confirm_destination;
    QFont typeface;
    QPushButton *btn_line_1;
    QPushButton *btn_line_2;
    QPushButton *btn_line_3;
    QPushButton *btn_line_4;
    QPushButton *btn_default_picture;

signals:
    void buy_ticket_destination_back();
    void back_to_mainscence_buy_ticket_destination();
};

#endif // BUY_TICKET_DESTINATION_H

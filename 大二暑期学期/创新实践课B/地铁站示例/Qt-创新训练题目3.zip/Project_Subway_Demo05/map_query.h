/********************************************************************************
  * 文件名：map_query.h
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：地图查询界面窗口头文件，声明了相关按钮、输入栏对象，并设置了一些信号函数以及计时器
  *
  ******************************************************************************
  * 注意：
  *
  ******************************************************************************  */
#ifndef MAP_QUERY_H
#define MAP_QUERY_H

#include <QMainWindow>
#include <QLabel>
#include <QPainter>
#include <QPushButton>
#include <QKeyEvent>
#include <QLineEdit>
#include <QCompleter>
#include <QLabel>
#include <QTimer>
#include <math.h>

#include "buy_ticket_origin.h"

class map_query : public QMainWindow
{
    Q_OBJECT
public:
    explicit map_query(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    void keyReleaseEvent(QKeyEvent * event);
    int get_station_information(QString i_station_name);
    void show_information(int station_node,QLabel& i_information_station_label);
    void mousePressEvent(QMouseEvent *e);
    void mouseMoveEvent(QMouseEvent *e);
    void mouseReleaseEvent(QMouseEvent *);

private:
    const int WIDTH=1080;
    const int HEIGHT=668;
    QTimer *show_information_timer;
    QLineEdit *query_station;
    QStringList station_list;
    QCompleter *station_name;
    QPushButton *btn_esc;
    QPushButton *btn_search;
    QPushButton *btn_enter_buy_ticket;
    QPushButton *btn_zoomin;
    QPushButton *btn_zoomout;
    QPushButton *btn_default;
    QFont typeface;

signals:
    void map_query_back();
    void map_query_switch();

};

#endif // MAP_QUERY_H

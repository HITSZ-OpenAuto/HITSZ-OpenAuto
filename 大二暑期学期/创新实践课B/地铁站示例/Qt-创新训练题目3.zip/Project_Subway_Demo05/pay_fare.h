/********************************************************************************
  * 文件名：pay_fare.h
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：购票界面组购票数量窗口头文件，声明了相关按钮、显示控件以及定时器
  *
  ******************************************************************************
  * 注意：该文件声明了double类型的全局变量station_price，用以获得用户选择的线路的票价
  *
  ******************************************************************************  */
#ifndef PAY_FARE_H
#define PAY_FARE_H

#include <QWidget>
#include <QPainter>
#include <QKeyEvent>
#include <QLineEdit>
#include <QLabel>
#include <QPushButton>
#include <QChar>
#include <QMessageBox>
#include <QDialog>
#include <QTimer>
#include <QFont>

#include "confirm_purchase.h"
#include "information_subway.h"

extern double station_price;

namespace Ui {
class pay_fare;
}

class pay_fare : public QWidget
{
    Q_OBJECT

public:
    explicit pay_fare(QWidget *parent = nullptr);
    ~pay_fare();
    void paintEvent(QPaintEvent *);
    void keyReleaseEvent(QKeyEvent * event);

private:
    Ui::pay_fare *ui;

    const int WIDTH=1080;
    const int HEIGHT=668;
    confirm_purchase *window_confirm_purchase;
    QLabel * show_price;
    QTimer *show_price_timer;
    QLineEdit *number_tickets;
    QPushButton *btn_esc;
    QPushButton * btn_confirm_number;
    QFont typeface;

signals:
    void pay_fare_back();
    void back_to_mainscence_pay_fare();
};

#endif // PAY_FARE_H

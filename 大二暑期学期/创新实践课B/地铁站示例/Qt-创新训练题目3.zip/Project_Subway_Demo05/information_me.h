/********************************************************************************
  * 文件名：information_me.h
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：用户指引界面头文件，声明了相关按钮
  *
  ******************************************************************************
  * 注意：
  *
  ******************************************************************************  */
#ifndef INFORMATION_ME_H
#define INFORMATION_ME_H

#include <QDialog>
#include <QPushButton>
#include <QPainter>
#include <QLabel>
#include <QHBoxLayout>
#include <QWheelEvent>

namespace Ui {
class information_me;
}

class information_me : public QDialog
{
    Q_OBJECT

public:
    explicit information_me(QWidget *parent = nullptr);
    ~information_me();
    void paintEvent(QPaintEvent *);
    void wheelEvent(QWheelEvent *event);

private:
    Ui::information_me *ui;

    double notice_height=0;
    QPushButton *btn_confirm;

};

#endif // INFORMATION_ME_H

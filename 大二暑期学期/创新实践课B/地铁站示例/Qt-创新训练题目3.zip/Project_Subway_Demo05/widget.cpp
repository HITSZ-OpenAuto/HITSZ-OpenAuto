/********************************************************************************
  * 文件名：widget.cpp
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：主窗口实现文件，对主窗口的标题、界面大小、以及相关的函数、按钮等进行了设置，
  *      并重写了绘图事件函数，绘制主界面背景
  *
  ******************************************************************************
  * 注意：该文件通过信号和槽的机制关联了相关的购票界面、地图查询界面
  *
  ******************************************************************************  */
#include "widget.h"
#include "ui_widget.h"

int x1=0,x2=0;

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    setWindowTitle("地铁售票系统v0.1");
    setFixedSize(WIDTH,HEIGHT);
    this->setWindowIcon(QPixmap(":/subway/mysource/logo.png"));

    window_buy_ticket = new Buy_Ticket_Origin;
    window_map_query = new map_query;
    connect(window_buy_ticket,&Buy_Ticket_Origin::buy_ticket_back,this,[=](){
        this->show();
        window_buy_ticket->hide();
        this->setGeometry(window_buy_ticket->geometry());
    });//连接主界面和购票界面，监视购票界面的返回信号

    connect(window_map_query,&map_query::map_query_back,this,[=](){
        this->show();
        window_map_query->hide();
        this->setGeometry(window_map_query->geometry());
    });//连接地图查询界面和主界面，当按下返回键后，回到主界面

    connect(window_map_query,&map_query::map_query_switch,this,[=](){
        window_buy_ticket->show();
        window_map_query->hide();
        window_buy_ticket->setGeometry(window_map_query->geometry());
    });//监视地图查询界面发送的切换信号，接受后，从地图查询界面切换到购票界面

    mainscence_btn1=new QPushButton("开始购票",this);
    mainscence_btn1->setGeometry(794,140,160,100);
    connect(mainscence_btn1,&QPushButton::clicked,this,[=](){
        window_buy_ticket->show();
        this->hide();
        window_buy_ticket->setGeometry(this->geometry());
    });//1号按钮，实现在购票界面和主界面之间的切换

    mainscence_btn2=new QPushButton("线路查询",this);
    mainscence_btn2->setGeometry(794,280,160,100);
    connect(mainscence_btn2,&QPushButton::clicked,this,[=](){
        window_map_query->show();
        this->hide();
        window_map_query->setGeometry(this->geometry());
    });//2号按钮，按下后进入地图查询界面

    mainscence_btn3=new QPushButton("退出系统",this);
    mainscence_btn3->setGeometry(794,420,160,100);
    connect(mainscence_btn3,&QPushButton::clicked,this,&Widget::close);
    //3号按钮，实现系统的退出

    information_author=new QLabel("黄继凡 2021.7.1--\n模拟地铁自动售票系统\nv1.3",this);
    information_author->move(940,600);

    palette.setColor(QPalette::WindowText,Qt::white);
    information_author->setPalette(palette);//字体颜色设置

    typeface.setPixelSize(25);
    typeface.setFamily("楷体");
    typeface.setBold(true);
    mainscence_btn1->setFont(typeface);
    mainscence_btn2->setFont(typeface);
    mainscence_btn3->setFont(typeface);
}

void Widget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap mainscence;
    mainscence.load(":/subway/mysource/subway1.png");
    painter.drawPixmap(0,0,this->width(),this->height(),mainscence);
}

Widget::~Widget()
{
    delete ui;
}


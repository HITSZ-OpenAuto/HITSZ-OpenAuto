/********************************************************************************
  * 文件名：information_subway.h
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：站点距离计算模块头文件
  *
  ******************************************************************************
  * 注意：该文件中声明了一个自定义结构体station_demo类型的全局变量数组stations_search[14]
  *      以及QString类型的全局变量数组station_list_route[14]，以便执行查询功能和输出站点间的路径
  ******************************************************************************  */
#ifndef INFORMATION_SUBWAY_H
#define INFORMATION_SUBWAY_H

#include <string>
#include <QString>

struct station_demo
{
    QString name="0";
    int node=0;
};
extern station_demo stations_search[14];

extern QString station_list_route[14];

int get_information_of_subway(QString i_origin,QString i_destination);

class information_subway
{
public:

private:

};

#endif // INFORMATION_SUBWAY_H

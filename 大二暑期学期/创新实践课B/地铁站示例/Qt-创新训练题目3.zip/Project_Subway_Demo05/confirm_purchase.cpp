/********************************************************************************
  * 文件名：confirm_purchase.cpp
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：确认支付界面实现文件，通过输入栏获得用户输入的金额，并通过比较输入金额和计算票价的大小，
  *      进行不同情况的处理，当金额足够时，将显示支付成功，否则显示支付失败
  ******************************************************************************
  * 注意：该文件中使用了来自pay_fare文件中的double类型的station_price变量，用以比较用户支
  *      付金额和票价支付成功后，该窗口将发送一个回到主界面的信号，程序将逐级回到主界面并对将
  *      各界面的输入栏进行清空
  ******************************************************************************  */
#include "confirm_purchase.h"
#include "ui_confirm_purchase.h"

#include "pay_fare.h"

confirm_purchase::confirm_purchase(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::confirm_purchase)
{
    ui->setupUi(this);
    setWindowTitle("确认支付");
    setFixedSize(360,240);
    this->setWindowModality(Qt::ApplicationModal);
    this->setWindowIcon(QPixmap(":/subway/mysource/logo.png"));

    money_pay=new QLineEdit(this);
    money_pay->setPlaceholderText("在此输入您的支付金额");
    money_pay->setGeometry(130,70,100,30);

    btn_yes=new QPushButton("确认支付",this);
    btn_yes->move(100,200);
    connect(btn_yes,&QPushButton::clicked,this,[=](){
       QString pay_passager=money_pay->text();
       double i=pay_passager.toULong();
       if(i>=station_price)
       {
           i=i-station_price;
           QString change=QString::number(i);
           QMessageBox::information(this,"支付成功","您已完成支付\n 找零"+change+"元");
           money_pay->clear();
           emit back_to_mainscence_confirm_purchase();
       }
       else
       {
           QMessageBox::information(this,"支付失败","您支付的金额不足，已退回");
       }
    });

    btn_no=new QPushButton("取消",this);
    btn_no->move(200,200);
    connect(btn_no,&QPushButton::clicked,this,[=](){
        emit confirm_purchase_back();
    });
}

confirm_purchase::~confirm_purchase()
{
    delete ui;
}

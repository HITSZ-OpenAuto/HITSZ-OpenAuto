/********************************************************************************
  * 文件名：buy_ticket.cpp
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：购票界面组起点站输入窗口实现文件，重写了绘图事件和相关键盘事件，实现界面背景绘制和Esc键返回
  *      接收输入栏中输入的站点名，并进行相应判断
  ******************************************************************************
  * 注意：该文件中使用了information_subway文件中的自定义结构体station_demo类型的全局
  *      变量数组stations_search[14]，进行输入站点的比较判断
  ******************************************************************************  */
#include "buy_ticket_origin.h"
#include "ui_buy_ticket.h"

QString my_origin="default";
QString my_destination="default";

Buy_Ticket_Origin::Buy_Ticket_Origin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Buy_Ticket)
{
    ui->setupUi(this);
    setWindowTitle("地铁售票系统v0.1");
    setFixedSize(WIDTH,HEIGHT);
    this->setWindowIcon(QPixmap(":/subway/mysource/logo.png"));

    window_buy_ticket_destination=new buy_ticket_destination;

    route_enquiry_origin = new QLineEdit(this);//输入查询，获得用户输入的起点站
    route_enquiry_origin->setPlaceholderText("在此处输入起点站");
    route_enquiry_origin->setGeometry(820,200,240,110);

    station_list <<"怒江公园" <<"北陵公园" <<"丁香湖" <<"淮河街沈医二院" <<"中医药大学" <<"重工街"
                 <<"铁西广场" <<"青年大街" <<"滂江街" <<"黎明广场" <<"奥体中心" <<"长青南街" <<"全运路" <<"张沙布";
    station_name = new QCompleter(station_list); //设置Eidt的模糊查询对象
    route_enquiry_origin->setCompleter(station_name);

    btn_esc = new QPushButton("返回主界面",this);
    btn_esc ->setGeometry(960,600,100,62);
    connect(btn_esc,&QPushButton::clicked,this,[=](){
        emit this->buy_ticket_back();
    });//返回按钮，按下返回主界面按钮后，返回主界面

    btn_confirm_origin = new QPushButton("确认",this);
    btn_confirm_origin->setGeometry(820,400,240,100);//确认按钮，按下确认按钮后，检测输入站点是否在列表中
    connect(btn_confirm_origin,&QPushButton::clicked,this,[=](){
        my_origin=route_enquiry_origin->text();
        bool wt_valid_origin=false;
        for(int i=0;i<=13;i++)
        {
            if(my_origin==stations_search[i].name)
            {
                wt_valid_origin=true;
                break;
            }
        }
        if(wt_valid_origin)
        {
            window_buy_ticket_destination->show();
            this->hide();
            window_buy_ticket_destination->setGeometry(this->geometry());
        }//准备添加若输入的不是某一个站点的名字，则进行提示
        else
        {
            QMessageBox::critical(this,"错误","您输入的站点不在列表中");
        }
    });

    connect(window_buy_ticket_destination,&buy_ticket_destination::buy_ticket_destination_back,this,[=](){
       this->show();
       window_buy_ticket_destination->hide();
       this->setGeometry(window_buy_ticket_destination->geometry());
    });//检测到发送的返回信号后，从终点站选择界面返回到当前的界面（起点站选择）

    connect(window_buy_ticket_destination,&buy_ticket_destination::back_to_mainscence_buy_ticket_destination,this,[=](){
        emit buy_ticket_back();
        route_enquiry_origin->clear();
        for(int i=0;i<=13;i++)
            station_list_route[i]="0";
    });//返回到主界面

    typeface.setPointSize(20);
    typeface.setFamily("华文新魏");
    route_enquiry_origin->setFont(typeface);
    route_enquiry_origin->setAlignment(Qt::AlignHCenter);
    typeface.setPixelSize(25);
    typeface.setFamily("楷体");
    typeface.setBold(true);
    btn_confirm_origin->setFont(typeface);
    typeface.setPixelSize(15);
    btn_esc->setFont(typeface);

}

Buy_Ticket_Origin::~Buy_Ticket_Origin()
{
    delete ui;
}

void Buy_Ticket_Origin::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap Buy_ticket_scence;
    Buy_ticket_scence.load(":/subway/mysource/background_01.png");
    painter.drawPixmap(0,0,this->width(),this->height(),Buy_ticket_scence);
    Buy_ticket_scence.load(":/subway/mysource/line_network.png");
    painter.drawPixmap(50,200,650,400,Buy_ticket_scence);
}//重新绘图事件，绘出购票界面背景

void Buy_Ticket_Origin::keyReleaseEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape)
    {
        emit buy_ticket_back();
    }
    if(event->key()==Qt::Key_Return)
    {
        bool wt_valid_origin=false;
        for(int i=0;i<=13;i++)
        {
            if(my_origin==stations_search[i].name)
            {
                wt_valid_origin=true;
                break;
            }
        }
        if(wt_valid_origin)
        {
            window_buy_ticket_destination->show();
            this->hide();
            window_buy_ticket_destination->setGeometry(this->geometry());
        }//准备添加若输入的不是某一个站点的名字，则进行提示
        else
        {
            QMessageBox::critical(this,"错误","您输入的站点不在列表中");
        }
    }
}

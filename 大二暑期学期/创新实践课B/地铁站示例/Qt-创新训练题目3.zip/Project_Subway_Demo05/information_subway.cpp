/********************************************************************************
  * 文件名：information_subway.h
  * 作者：黄继凡
  * 版本：v1.4
  * 日期：7.16
  * 摘要：站点距离计算模块实现文件，通过弗洛伊德算法获得站点网络中两点的最短路径，其中
  *      get_information_of_subway函数以两个QString对象作为输入站点，进行运算，并返回
  *      int类型的两个站点间的最短距离
  ******************************************************************************
  * 注意：本文件中get_information_of_subway函数被其它文件调用，另外头文件中声明全局变量
  *      被其它文件使用以输出站点间的最短路径
  ******************************************************************************  */
#include "information_subway.h"

#define INF 30000	//定义无穷大
#define size 1001	//最大数据规模

int path[size][size];//存路径
int dis[size][size];	//存距离

station_demo stations_search[14]={{"怒江公园",1},{"北陵公园",2},{"丁香湖",3},{"淮河街沈医二院",4},{"中医药大学",5},{"重工街",6},{"铁西广场",7},
                                  {"青年大街",8},{"滂江街",9},{"黎明广场",10},{"奥体中心",11},{"长青南街",12},{"全运路",13},{"张沙布",14}};

int i=0;
QString station_list_route[14]={"0","0","0","0","0","0","0","0","0","0","0","0","0","0"};

void init()//数组初始化函数
{
    for (int i = 0; i < size; i++)
        for (int j = 0; j < size; j++)
        {
            path[i][j] = j;//初始化路径为-1
            if (i != j)	//因为自己到自己的距离为0，所以矩阵的对角线始终为0，这步十分的关键
            {
                dis[i][j] = INF;
            }
            else
                dis[i][j]=0;
        }

}

void floyd(int n)//佛洛依德算法实现，n：顶点数目
{
    for (int k = 1; k <= n; k++)//k作为中转顶点
    {
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= n; j++)
            {
                if (dis[i][k] + dis[k][j] < dis[i][j])//递推公式，通过顶点k的路径距离更小则更新矩阵
                {
                    dis[i][j] = dis[i][k] + dis[k][j];//更新距离
                    path[i][j] = path[i][k];//更新路径，i到j的中转顶点为k
                }
            }
        }
    }
}

void print(int s, int e)//递归+回溯打印中间路径
{
    if (path[s][e] == e)
        return;//递归出口，路径中第一点与第二点之间的中转点为初始化值
    station_list_route[i]=stations_search[(path[s][e])-1].name;
    i++;
    print(path[s][e],e);
}

void print_path(int start, int end)//打印完整路径 start：起点，end：终点
{
    station_list_route[i]=stations_search[start-1].name;
    i++;
    print(start, end);
    station_list_route[i]=stations_search[end-1].name;
    i=0;
}

int get_information_of_subway(QString i_origin,QString i_destination)
{
    int a_replace[17]{1,2,3,4,4,6,5,5,8,7,7,8,11,9,9,11,12};
    int b_replace[17]{4,5,4,5,7,7,8,9,9,8,11,11,12,12,10,13,14};
    init();//初始化矩阵
    int n, m;
    n = 14;
    m = 17;
    int a, b, d=1;//此处更改了d的用处，假设所有站点间距离相同————
    for (int i = 0; i < m; i++)
    {
        //cin >> a >> b >> d;
        a = a_replace[i];
        b = b_replace[i];
        dis[a][b] = d;
        dis[b][a] = d;
    }
    floyd(n);
    int a_search = 0, b_search=0;//寻找输入的起点站、终点站对应的在图上的序号
    for(int i=0;i<=13;i++)
    {
        if(stations_search[i].name==i_origin)
            a_search=stations_search[i].node;
        if(stations_search[i].name==i_destination)
            b_search=stations_search[i].node;
    }
    a=a_search;
    b=b_search;
    print_path(a, b);
    return dis[a][b];
}

#include <opencv2/opencv.hpp>
#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <iostream>

using namespace std;
using namespace cv;

class Planner
{
public:
    Planner(ros::NodeHandle &n);
    ~Planner();

private:
};

Planner::Planner(ros::NodeHandle &n)
{
    cout << "Planner created";
}

Planner::~Planner()
{
    ROS_INFO("Planner has terminated");
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "second_task_node");
    ros::NodeHandle n;
    Planner p(n);

    return 0;
}